// Simple framed slideshow with dots and autoplay
const slides = Array.from(document.querySelectorAll('.slide'));
const dotsContainer = document.getElementById('dots');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
let current = 0;
let autoplay = true;
let interval = null;
const AUTOPLAY_MS = 4500;

function init() {
  slides.forEach((s, i) => {
    const btn = document.createElement('button');
    btn.addEventListener('click', () => goTo(i));
    if (i === 0) btn.classList.add('active');
    dotsContainer.appendChild(btn);
  });
  show(current);
  prevBtn.addEventListener('click', () => { goTo(current - 1); });
  nextBtn.addEventListener('click', () => { goTo(current + 1); });
  startAutoplay();
  // pause on hover for accessibility
  const frame = document.querySelector('.slideshow-frame');
  frame.addEventListener('mouseenter', pauseAutoplay);
  frame.addEventListener('mouseleave', startAutoplay);
}

function show(index) {
  slides.forEach((s, i) => {
    s.classList.toggle('active', i === index);
  });
  Array.from(dotsContainer.children).forEach((d, i) => {
    d.classList.toggle('active', i === index);
  });
}

function goTo(idx) {
  if (idx < 0) idx = slides.length - 1;
  if (idx >= slides.length) idx = 0;
  current = idx;
  show(current);
}

function startAutoplay() {
  if (!autoplay) return;
  stopAutoplay();
  interval = setInterval(() => { goTo(current + 1); }, AUTOPLAY_MS);
}

function stopAutoplay() {
  if (interval) clearInterval(interval);
}

function pauseAutoplay() { stopAutoplay(); }
function resumeAutoplay() { startAutoplay(); }

document.addEventListener('DOMContentLoaded', init);
